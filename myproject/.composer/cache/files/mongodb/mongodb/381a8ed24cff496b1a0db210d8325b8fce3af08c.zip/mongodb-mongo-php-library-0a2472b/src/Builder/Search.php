<?php

namespace MongoDB\Builder;

use MongoDB\Builder\Search\FactoryTrait;

final class Search
{
    use FactoryTrait;
}
