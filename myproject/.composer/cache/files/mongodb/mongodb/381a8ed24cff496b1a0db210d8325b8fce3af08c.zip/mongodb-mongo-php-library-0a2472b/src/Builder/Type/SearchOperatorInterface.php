<?php

namespace MongoDB\Builder\Type;

interface SearchOperatorInterface
{
}
